"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function areaRetangulo(base, altura) {
    return base * altura;
}
exports.default = areaRetangulo;
//# sourceMappingURL=retangulo.js.map