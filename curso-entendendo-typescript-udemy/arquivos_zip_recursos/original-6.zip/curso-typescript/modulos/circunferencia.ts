export const PI = 3.14

export function areaCircunferencia(raio: number): number {
    return raio * raio * PI
}