"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PI = 3.14;
function areaCircunferencia(raio) {
    return raio * raio * exports.PI;
}
exports.areaCircunferencia = areaCircunferencia;
//# sourceMappingURL=circunferencia.js.map