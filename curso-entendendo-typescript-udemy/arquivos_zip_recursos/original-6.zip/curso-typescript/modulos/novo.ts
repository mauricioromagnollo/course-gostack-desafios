module.exports = {
    digaOi(nome: string) {
        return "Oi " + nome
    }
}