"use strict";
module.exports = {
    digaOi(nome) {
        return "Oi " + nome;
    }
};
//# sourceMappingURL=novo.js.map