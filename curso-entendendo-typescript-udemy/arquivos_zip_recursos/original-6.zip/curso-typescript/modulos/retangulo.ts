export default function areaRetangulo(base: number, altura: number): number {
    return base * altura
}