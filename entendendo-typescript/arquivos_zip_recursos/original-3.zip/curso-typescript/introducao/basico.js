"use strict";
var a = 'Teste TS!';
console.log(a);
//# sourceMappingURL=basico.js.map