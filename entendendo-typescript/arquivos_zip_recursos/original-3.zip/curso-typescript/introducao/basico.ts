const a: string = 'Teste TS!'
console.log(a)