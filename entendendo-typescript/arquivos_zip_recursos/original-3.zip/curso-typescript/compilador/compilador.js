"use strict";
var canal = 'Gaveta';
var inscritos = 610234;
// canal = inscritos
console.log("Canal = " + canal);
// let nome = 'Pedro'
function soma(a, b) {
    return a + b;
}
var qualquerCoisa;
qualquerCoisa = 12;
qualquerCoisa = 'abc';
function saudar(isManha) {
    var saudacao;
    if (isManha) {
        saudacao = 'Bom Dia!';
    }
    else {
        saudacao = 'Tenha uma boa vida!';
    }
    return saudacao;
}
//# sourceMappingURL=compilador.js.map