"use strict";
var a = 'Teste TS!';
console.log(a);
